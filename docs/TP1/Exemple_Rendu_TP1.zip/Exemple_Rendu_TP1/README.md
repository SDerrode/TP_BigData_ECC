#  TP Linked Data et SparQL

### Ruben-Kévin Koua
---
Dans ce TP, il sera question de choisir une base de données linked data (autre que DBPedia) et d'inventer deux requêtes sur cette base.

#### Base de données utilisée

La base de données sur laquelle les requêtes ont été lancées est [warsampo](https://ldf.fi/warsa/sparql).
Le lien est : *https://ldf.fi/warsa/sparql*

> War sampo (la guerre de Sampo) s'est déroulée en Finlande durant la deuxième guerre mondiale.
> Les textes dans cette base de données sont en suedois et finnois

## Requête 1

**Les 50 principales causes de décès des prisoniers capturés hors de leurs lieu de résidence**

### Dessin RDF de la requête
![RDF1](RDF1.jpg)


### Code SparQL de la requête

```sparql
PREFIX prisoners: <http://ldf.fi/schema/warsa/prisoners/>

SELECT ?causeDeath (count(?causeDeath) as ?count)
WHERE {
  ?p prisoners:cause_of_death ?causeDeath;
     prisoners:municipality_of_residence ?residencePlace;
     prisoners:municipality_of_capture ?capturePlace.
  
  FILTER (?capturePlace != ?residencePlace)
}
GROUP BY ?causeDeath
ORDER BY DESC(?count)
LIMIT 50
```

### Les 4 premiers résultats de la requête

![prisonersCausesOfDeath1](prisonersCausesOfDeath1.PNG)

## Requête 2

**La liste des prisoniers qui ont été capturés et libérés durant la deuxième guerre mondiale (entre 1939-09-01 et 1945-09-02) ayant une occupation et au moins 1 enfant**

### Dessin RDF de la requête

![RDF2](RDF2.jpg)


### Code SparQL de la requête

```sparql
PREFIX prisoners: <http://ldf.fi/schema/warsa/prisoners/>

SELECT ?p ?dateCapture ?dateReturn ?occupation ?nbChildren
WHERE {
  ?p prisoners:date_of_capture ?dateCapture;
     prisoners:date_of_return ?dateReturn;
     prisoners:occupation_literal ?occupation;
     prisoners:number_of_children ?nbChildren.
     
  FILTER (?nbChildren !="0" && ?nbChildren !="0 ?")
  FILTER (?dateCapture >="1939-09-01"^^<http://www.w3.org/2001/XMLSchema#date> && ?dateCapture <="1945-09-02"^^<http://www.w3.org/2001/XMLSchema#date>)
  FILTER (?dateReturn >="1939-09-01"^^<http://www.w3.org/2001/XMLSchema#date> && ?dateReturn <="1945-09-02"^^<http://www.w3.org/2001/XMLSchema#date>)
}
ORDER BY (?dateCapture)

```

### Les 4 premiers résultats de la requête

![prisonersCapture2](prisonersCapture2.PNG)
